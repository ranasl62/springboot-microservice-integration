package com.example.demo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class Controller {

    @Autowired
    Listener listener;


    @Value("${demo.topic}")
    private String topic;

    @GetMapping("/msgs")
    public ResponseEntity<List<String>> getAllMessages() {
        return ResponseEntity.ok(listener.getMsgs());
    }

    @GetMapping("/info")
    public ResponseEntity<String> getInfo() {
        return ResponseEntity.ok("I am a demo service, I am listening to topic: " + topic);
    }
}

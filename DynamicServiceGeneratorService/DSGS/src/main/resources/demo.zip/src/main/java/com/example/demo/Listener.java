package com.example.demo;


import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class Listener {

    private static List<String> msgs = new ArrayList<>();

    @KafkaListener(topics = {"${demo.topic}"}, groupId = "group-1")
    public void message(@Payload String msg) {
        System.out.println(msg);
        msgs.add(msg);
    }

    public List<String> getMsgs() {
        return msgs;
    }
}
